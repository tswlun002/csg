#!/sv/sv_app/perl/rel/bin/perl

#$ cat Ops_FTP.pl
#####################################################
# Ops_FTP.pl - automated ftp script
# DEPENDENCIES - Ops_FTP.ini
# Version: 2.0 Date: 14th of August, 2015
# Added Email notification list
#####################################################

#BEGIN # necessary for this to execute properly from cron
#{
  #unshift @INC, qw(/sv/sv_app/gnu/perl/rel/lib/5.8.1 /sv/sv_app/gnu/perl/rel/lib/5.8.1/IA64.ARCHREV_0-LP64);
#}
=PROD

use warnings;
my $MyEnv = `whoami`;
chomp $MyEnv;
use strict;
use Net::FTP;
require "/sv/${MyEnv}/data/PE/lib/Ops_Functions.pl";

##
# Variable Declarations
##
my $LogDir = "/sv/${MyEnv}/data/PE/logs"; # Launch info for prod
my $myName = 'Ops_FTP';
my $IniDir = "/sv/${MyEnv}/data/PE/ini";  # prod
my $IniFile = "${myName}.ini";
my $IniLine; # contains lines from ini file
my @IniArray; #will contain parm and value for hash population
my %IniHash; # contains a hash of the initialization vars
my %opt; # command options hash
my $ftp; # FTP handle
my $key; # used to confirm the hash variables
my @date;
my $time; #YYMMDDHHMMSS
my $i; #generic var
my $logfile; # This is for the launch info
my $answer;
my $ArchiveFlag;
my $TempDir; # temp archive dir
my $ExitValue; # for system command return code checking
my $FileCount; # count the number of files ftp'd
my @FileList;
my $MsgHdr; # header for print statements
my $FndCust = 0;
my $RemSize;
my $LocSize;
my $eITCv = 'ITC';
my $eMList = 'EMAILLIST';
my @elines;
my @eList;
my @eListGrep;
my @eUncomment;
CHECK_PARMS() if $ARGV[0];

USAGEMSG() unless ($opt{c});
$MsgHdr = "${myName} -- ${opt{c}}:";

$time = &get_time();


$logfile = "${LogDir}/${myName}" . substr($time,0,8) . ".log";
open (LOG,">>$logfile") or
  die "** Ops_FTP.pl ERROR -- cannot open logfile $logfile\n";
Lprint("\n${MsgHdr} started at $time");

open (INI,"<${IniDir}/${IniFile}") || Ldie("${MsgHdr} ** Ops_FTP fatal error cannot" .
     " open INI file: ${IniDir}/${IniFile}");

while (<INI>)
{
 chomp;
 $IniLine = $_;
 CASE:
 {
  ($IniLine =~ /^#/) && last CASE;

  ($IniLine =~/^$opt{c}/) && do
  {
    $FndCust = 1;
    @IniArray = split(";",$IniLine);
    shift (@IniArray);
    $IniHash{$IniArray[0]} = $IniArray[1];
    last CASE;
  };
  last CASE;
 }
}
Ldie("${MsgHdr} Customer ${opt{c}} not configured in ini.  Exiting...") unless $FndCust;
#foreach $key (sort keys %IniHash)
#{
  #print "The value of $key is: $IniHash{$key}\n" if $IniHash{$key};
#}

##
# Before doing a bunch of work, confirm there are files to send
##

chdir(${IniHash{SOURCE}}) || Ldie("${MsgHdr} ${IniHash{SOURCE}} is not a valid source directory");
Lprint("${MsgHdr} Sourcing files from: ${IniHash{SOURCE}}");
@FileList = glob "*${IniHash{PATTERN}}*";
Ldie("${MsgHdr} No files to ftp in ${IniHash{SOURCE}}.  Exiting...") if scalar @FileList == 0;


##
# Check if we are archiving. If not: confirm.  If so, confirm dir
##

if ($IniHash{ARCHIVE})
{
  if (-d $IniHash{ARCHIVE}&& -W $IniHash{ARCHIVE})
  {
    $ArchiveFlag = 1;
##
# Here is how archive will work. create a temp folder in the archive directory
# based on time so will be unique.  Move the files there once ftp'd.  Once all
# the ftp'ing is done, tar and zip those files into the archive directory, and
# then remove the temporary directory along with the contents.
#
# We will create the temp dir now in the archive directory
##

    $TempDir = "${IniHash{ARCHIVE}}/temp_${time}";
    system("mkdir $TempDir");
    $ExitValue = $? >>8; # shift left 8 to find rc
    $ExitValue == 0 || Ldie("${MsgHdr} Error creating temp archive directory.  RC=$ExitValue");
  }
  else
  {
    Ldie("${MsgHdr} Problem accessing Archive dir $IniHash{ARCHIVE}. Can I write to it?");
  }
}
else
{
  Lprint("${MsgHdr} No Archive Directory Specified. Files will be left in place after FTP.");
  unless ($opt{q})
  {
    $answer = interactive("Is this okay");
print "Answer is: $answer\n";
    Ldie("${MsgHdr} User aborted due to no archiving") if $answer ne "Y";
  }
  $ArchiveFlag = 0;
  Lprint("$MsgHdr These files will NOT be archived");
}


##
# Now, prepare to ftp the files
##

Lprint ("${MsgHdr} Server: $IniHash{IP} User: $IniHash{ID}");
my $ftp = Net::FTP->new($IniHash{IP}) ||
   Ldie("${MsgHdr} Error connecting. Network or server problem?");
$ftp->login($IniHash{ID}, $IniHash{PW}) or
   Ldie("${MsgHdr} Error logging in. Has ID or password changed?");
$ftp->binary();

if ($IniHash{TARGET})
{
  $ftp->cwd($IniHash{TARGET}) ||
    Ldie("${MsgHdr} Error changing to target dir: $IniHash{TARGET}");
  Lprint("${MsgHdr} copying to remote directory: $IniHash{TARGET}");
}
##
# Now we are ready to ftp.  Perl's FTP does not support mput so we have to
# do it one file at a time.  Bummer, man.
##

$FileCount=0;
foreach (@FileList)
{
  unless (-d "${_}")
  {
    $ftp->put("${_}") ||
     Ldie("${MsgHdr} Error uploading ${_}. Disk space or permissions problems?");
     Lprint("${MsgHdr} transfered $_");
       if (${opt{c}} eq $eITCv) {
      open eINPUT, "<${IniDir}/${IniFile}";
              @elines = <eINPUT>;
      close eINPUT;
      @eUncomment = grep {!/^#/} @elines;
         @eListGrep = grep (/$eMList/,@eUncomment);
             unless (@eListGrep) {
                    Ldie("${MsgHdr} Unable to filter email entry from INI file: ${IniDir}/${IniFile}. Please investigate.");
               }
             @eList = split(";","@eListGrep");
     system("echo \"Transferred ${_} File\"|mailx -s \"File: ${_} Transferred\" ${eList[-1]}");
     } else {
      Lprint("${MsgHdr} No email notification for Customer: ${opt{c}}");
     }
     $FileCount++;
     if ($opt{v})
     {
       $RemSize = $ftp->size($_);
       $LocSize = -s ${_};
       Lprint("${MsgHdr}: Local File Size: ${LocSize}");
       Lprint("${MsgHdr}: Remote File Size: ${RemSize}\n");
     }
##
# Archiving
##
    if ($ArchiveFlag)
    {
      system("mv ${_} $TempDir");
      $ExitValue = $? >>8; # shift left 8 to find rc
      Ldie("${MsgHdr} Error moving ${_} to $TempDir") unless $ExitValue == 0;
    }
  }
}
Lprint("${MsgHdr} $FileCount files transferred");
$ftp->quit() or
   Lprint("${MsgHdr} Error disconnecting.???");

CleanUp() unless $FileCount > 0;

##
# Now zip the archived files in the temp dir to the real archive dir, and delete
# the files and temp dir
##

if ($ArchiveFlag)
{
  Lprint("${MsgHdr} Archiving files to: $IniHash{ARCHIVE}");
  chdir("$TempDir") || Ldie("${MsgHdr} Failed changing to dir $TempDir to tar files");
system ("tar -cvf - *${IniHash{PATTERN}}* | gzip > $IniHash{ARCHIVE}/" .
        "${opt{c}}${time}.tar.gz");
  #system ("/usr/local/bin/tar -cvf - * | /usr/local/bin/gzip > $IniHash{ARCHIVE}/" .
  $ExitValue = $? >>8; # shift left 8 to find rc
   Ldie("${MsgHdr} Error zipping files from $TempDir to $IniHash{ARCHIVE}") unless $ExitValue == 0;
}
##
# Clean up and exit
##

CleanUp(); #This will also exit the script
exit; # Just in case

##
# Subroutines
##

##               ##
sub CleanUp      ##
##               ##
{
# clean up the tempdirs and temp files
chdir("$IniHash{ARCHIVE}") || Lprint("${MsgHdr} Failed changing to dir $IniHash{ARCHIVE} to begin cleanup.\n");
system("/bin/rm -rf $TempDir");
$ExitValue = $? >>8; # shift left 8 to find rc
Lprint("${MsgHdr} Warning: Unsuccessful deletion of temp space: $TempDir") unless $ExitValue == 0;

$time = &get_time();
Lprint("${MsgHdr} completed successfully at $time.");
exit 0;
}


##               ##
sub CHECK_PARMS  ##
##               ##
{
use Getopt::Std;
# the : is needed after the switch if an argument is expected.
  getopts("c:qvh", \%opt) || &USAGEMSG;

  &USAGEMSG() if $opt{h};

##
# This is all that is necessary.  Parameter values now in hash
##
}

##            ##
sub USAGEMSG  ##
##            ##

{
  print STDERR << "EOF";

This script ftp's files to customers as defined in the Ops_FTP.ini file

Usage: $0 -c CUSTOMER [-q][-v][-h]  WHERE

      -c CUSTOMER  : CUSTOMER is the customer code as per the ini file
      -q           : Quiet: does not ask for confirmation if no Archive
      -v           : Verbose: prints local and remote filesize for each file sent
      -h           : this (help) message

    example: $0 -c ITC
EOF
exit;
}

********************************************************************************************************************
Prod script:

svc_cyk_SingleVR_App.sklsvprd.nlasvwrva10> (/sv/sklsvprd/data/PE/scripts)
$ cat Ops_FTP.pl


=cut

#!/sv/sv_app/perl/rel/bin/perl
#############################################################################
# Ops_FTP.pl - automated ftp script
# DEPENDENCISE - Ops_FTP.ini
# Version: 2.0 Date: 14th of August, 2015
# Added Email notification list
####-------------------------------------------------------------------------
# REVISION HISTORY:
# #   $Log: Ops_FTP.pl,v $
# #   Revision 2.10  22th April, 2020  Ibrahim M.D
# #   Modified the script to be compatible Siyakhula environment (Linux)
# #   Convert the script from ftp and sftp file transfer.
#############################################################################
#BEGIN # necessary for this to execute properly from cron
#{
  #unshift @INC, qw(/sv/sv_app/gnu/perl/rel/lib/5.8.1 /sv/sv_app/gnu/perl/rel/lib/5.8.1/IA64.ARCHREV_0-LP64);
#}
use warnings;
my $MyEnv = `whoami`;
chomp $MyEnv;
use strict;
#use Net::FTP;
use Net::SFTP::Foreign;
use File::Path;
use File::Spec;
require "/sv/${MyEnv}/data/PE/lib/Ops_Functions.pl";

##
# Variable Declarations
##


#my $LogDir = '/sv/${MyEnv}/work/dantso_i/Ops_FTP'; # Launch info for test
my $LogDir = "/sv/${MyEnv}/data/PE/logs"; # Launch info for prod
my $myName = 'Ops_FTP';
#my $IniDir = "/sv/${MyEnv}/work/dantso_i/Ops_FTP"; # testing
my $IniDir = "/sv/${MyEnv}/data/PE/ini";  # prod
my $IniFile = "${myName}.ini";
my $IniLine; # contains lines from ini file
my @IniArray; #will contain parm and value for hash population
my %IniHash; # contains a hash of the initialization vars
my %opt; # command options hash
my $ftp; # FTP handle
my $sftp; # SFTP handle
my $key; # used to confirm the hash variables
my @date;
my $time; #YYMMDDHHMMSS
my $i; #generic var
my $logfile; # This is for the launch info
my $answer;
my $ArchiveFlag;
my $TempDir; # temp archive dir
my $ExitValue; # for system command return code checking
my $FileCount; # count the number of files ftp'd
my @FileList;
my $MsgHdr; # header for print statements
my $FndCust = 0;
my $RemSize;
my $LocSize;
my $eITCv = 'ITC';
my $eMList = 'EMAILLIST';
my @elines;
my @eList;
my @eListGrep;
my @eUncomment;
CHECK_PARMS() if $ARGV[0];

USAGEMSG() unless ($opt{c});
$MsgHdr = "${myName} -- ${opt{c}}:";

$time = &get_time();


$logfile = "${LogDir}/${myName}" . substr($time,0,8) . ".log";
open (LOG,">>$logfile") or
  die "** Ops_FTP.pl ERROR -- cannot open logfile $logfile\n";
Lprint("\n${MsgHdr} started at $time");

open (INI,"<${IniDir}/${IniFile}") || Ldie("${MsgHdr} ** Ops_FTP fatal error cannot" .
     " open INI file: ${IniDir}/${IniFile}");

while (<INI>)
{
 chomp;
 $IniLine = $_;
 CASE:
 {
  ($IniLine =~ /^#/) && last CASE;

  ($IniLine =~/^$opt{c}/) && do
  {
    $FndCust = 1;
    @IniArray = split(";",$IniLine);
    shift (@IniArray);
    $IniHash{$IniArray[0]} = $IniArray[1];
    last CASE;
  };
  last CASE;
 }
}
Ldie("${MsgHdr} Customer ${opt{c}} not configured in ini.  Exiting...") unless $FndCust;
#foreach $key (sort keys %IniHash)
#{
  #print "The value of $key is: $IniHash{$key}\n" if $IniHash{$key};
#}

##
# Before doing a bunch of work, confirm there are files to send
##

chdir(${IniHash{SOURCE}}) || Ldie("${MsgHdr} ${IniHash{SOURCE}} is not a valid source directory");
Lprint("${MsgHdr} Sourcing files from: ${IniHash{SOURCE}}");
@FileList = glob "*${IniHash{PATTERN}}*";
Ldie("${MsgHdr} No files to sftp in ${IniHash{SOURCE}}.  Exiting...") if scalar @FileList == 0;


##
# Check if we are archiving. If not: confirm.  If so, confirm dir
##

if ($IniHash{ARCHIVE})
{
  if (-d $IniHash{ARCHIVE}&& -W $IniHash{ARCHIVE})
  {
    $ArchiveFlag = 1;
##
# Here is how archive will work. create a temp folder in the archive directory
# based on time so will be unique.  Move the files there once sftp'd.  Once all
# the sftp'ing is done, tar and zip those files into the archive directory, and
# then remove the temporary directory along with the contents.
#
# We will create the temp dir now in the archive directory
##

    $TempDir = "${IniHash{ARCHIVE}}/temp_${time}";
    system("mkdir $TempDir");
    $ExitValue = $? >>8; # shift left 8 to find rc
    $ExitValue == 0 || Ldie("${MsgHdr} Error creating temp archive directory.  RC=$ExitValue");
  }
  else
  {
    Ldie("${MsgHdr} Problem accessing Archive dir $IniHash{ARCHIVE}. Can I write to it?");
  }
}
else
{
  Lprint("${MsgHdr} No Archive Directory Specified. Files will be left in place after FTP.");
  unless ($opt{q})
  {
    $answer = interactive("Is this okay");
print "Answer is: $answer\n";
    Ldie("${MsgHdr} User aborted due to no archiving") if $answer ne "Y";
  }
  $ArchiveFlag = 0;
  Lprint("$MsgHdr These files will NOT be archived");
}


##
# Now, prepare to sftp the files
##

Lprint ("${MsgHdr} Server: $IniHash{IP} User: $IniHash{ID}");
 $sftp = Net::SFTP::Foreign->new( $IniHash{IP},
                                    user => $IniHash{ID},
                                    stderr_discard => 1  );
   #Ldie("${MsgHdr} Unable to establish SFTP connection to $IniHash{IP}. Has ID changed? or Password expired?");
#$ftp->login($IniHash{ID}, $IniHash{PW}) or
   #Ldie("${MsgHdr} Error logging in. Has ID or password changed?");
#   Ldie("${MsgHdr} Error logging in. Has ID changed? or Password expired?");
#$sftp->binary();
  ( $sftp ) ||
      Ldie("${MsgHdr} Unable to establish SFTP connection to $IniHash{IP}. Please confirm IP and the password keys.");

if ($IniHash{TARGET})
{
  #$sftp->cwd($IniHash{TARGET}) ||
  $sftp->setcwd($IniHash{TARGET}) ||
    Ldie("${MsgHdr} Error changing to target dir: $IniHash{TARGET}");
  Lprint("${MsgHdr} copying to remote directory: $IniHash{TARGET}");
}
##
# Now we are ready to sftp.  Perl's FTP does not support mput so we have to
# do it one file at a time.  Bummer, man.
##

$FileCount=0;
foreach (@FileList)
{
  unless (-d "${_}")
  {
    $sftp->put("${_}") ||
     Ldie("${MsgHdr} Error uploading ${_}. Disk space or permissions problems?");
     Lprint("${MsgHdr} transfered $_");
       if (${opt{c}} eq $eITCv) {
      open eINPUT, "<${IniDir}/${IniFile}";
              @elines = <eINPUT>;
      close eINPUT;
      @eUncomment = grep {!/^#/} @elines;
         @eListGrep = grep (/$eMList/,@eUncomment);
             unless (@eListGrep) {
                    Ldie("${MsgHdr} Unable to filter email entry from INI file: ${IniDir}/${IniFile}. Please investigate.");
               }
             @eList = split(";","@eListGrep");
     system("echo \"Transferred ${_} File\"|mailx -s \"File: ${_} Transferred\" ${eList[-1]}");
     } else {
      Lprint("${MsgHdr} No email notification for Customer: ${opt{c}}");
     }
     $FileCount++;
     if ($opt{v})
     {
       #$RemSize = $ftp->size($_);
       my $Rsize = $sftp->stat($_);
       $RemSize = $Rsize->size;
       $LocSize = -s ${_};
       Lprint("${MsgHdr}: Local File Size: ${LocSize}");
       Lprint("${MsgHdr}: Remote File Size: ${RemSize}\n");
     }
##
# Archiving
##
    if ($ArchiveFlag)
    {
      system("mv ${_} $TempDir");
      $ExitValue = $? >>8; # shift left 8 to find rc
      Ldie("${MsgHdr} Error moving ${_} to $TempDir") unless $ExitValue == 0;
    }
  }
}
Lprint("${MsgHdr} $FileCount files transferred");
#$sftp->quit() or
$sftp->disconnect or
   Lprint("${MsgHdr} Error disconnecting.???");

CleanUp() unless $FileCount > 0;

##
# Now zip the archived files in the temp dir to the real archive dir, and delete
# the files and temp dir
##

if ($ArchiveFlag)
{
  Lprint("${MsgHdr} Archiving files to: $IniHash{ARCHIVE}");
  chdir("$TempDir") || Ldie("${MsgHdr} Failed changing to dir $TempDir to tar files");
system ("tar -cvf - *${IniHash{PATTERN}}* | gzip > $IniHash{ARCHIVE}/" .
        "${opt{c}}${time}.tar.gz");
  #system ("/usr/local/bin/tar -cvf - * | /usr/local/bin/gzip > $IniHash{ARCHIVE}/" .
  $ExitValue = $? >>8; # shift left 8 to find rc
   Ldie("${MsgHdr} Error zipping files from $TempDir to $IniHash{ARCHIVE}") unless $ExitValue == 0;
}
##
# Clean up and exit
##

CleanUp(); #This will also exit the script
exit; # Just in case

##
# Subroutines
##

##               ##
sub CleanUp      ##
##               ##
{
# clean up the tempdirs and temp files
chdir("$IniHash{ARCHIVE}") || Lprint("${MsgHdr} Failed changing to dir $IniHash{ARCHIVE} to begin cleanup.\n");
system("/bin/rm -rf $TempDir");
$ExitValue = $? >>8; # shift left 8 to find rc
Lprint("${MsgHdr} Warning: Unsuccessful deletion of temp space: $TempDir") unless $ExitValue == 0;

$time = &get_time();
Lprint("${MsgHdr} completed successfully at $time.");
exit 0;
}

##               ##
sub CHECK_PARMS  ##
##               ##
{
use Getopt::Std;
# the : is needed after the switch if an argument is expected.
  getopts("c:qvh", \%opt) || &USAGEMSG;

  &USAGEMSG() if $opt{h};

##
# This is all that is necessary.  Parameter values now in hash
##
}

##            ##
sub USAGEMSG  ##
##            ##

{
  print STDERR << "EOF";

This script ftp's files to customers as defined in the Ops_FTP.ini file

Usage: $0 -c CUSTOMER [-q][-v][-h]  WHERE

      -c CUSTOMER  : CUSTOMER is the customer code as per the ini file
      -q           : Quiet: does not ask for confirmation if no Archive
      -v           : Verbose: prints local and remote filesize for each file sent
      -h           : this (help) message

    example: $0 -c ITC
EOF
exit;
}


=CRONTAB

svc_cyk_SingleVR_App.sklsvprd.nlasvwrva10> (/sv/sklsvprd/data/PE/scripts)

$

**************************************************************************************
from crontab in prod:

#00 10 * * * /sv/sklsvprd/data/PE/cron/Ops_FTP_ITC.cron > /sv/sklsvprd/data/PE/logs/Ops_FTP_ITC.log 2>&1


svc_cyk_SingleVR_App.sklsvprd.nlasvwrva10> (/sv/sklsvprd/work/svc_cyk_SingleVR_App)
$ cat /sv/sklsvprd/data/PE/cron/Ops_FTP_ITC.cron
# ##########################################
# Wrapper for Ops_FTP.pl to work from cron
# Version: 2.1 Date: 1st of April, 2020
###########################################
. ./.profile
/sv/sklsvprd/data/PE/scripts/Ops_FTP.pl -c ITC -v
svc_cyk_SingleVR_App.sklsvprd.nlasvwrva10> (/sv/sklsvprd/work/svc_cyk_SingleVR_App)
$ cd /sv/sklsvprd/data/PE/scripts/
svc_cyk_SingleVR_App.sklsvprd.nlasvwrva10> (/sv/sklsvprd/data/PE/scripts)
$ ls -lrt Ops_FTP.pl
-rwxrwxr-x 1 sklsvprd sv 9265 Sep 29  2020 Ops_FTP.pl
svc_cyk_SingleVR_App.sklsvprd.nlasvwrva10> (/sv/sklsvprd/data/PE/scripts)
$ cat Ops_FTP.pl
#!/sv/sv_app/perl/rel/bin/perl
#############################################################################
# Ops_FTP.pl - automated ftp script
# DEPENDENCISE - Ops_FTP.ini
# Version: 2.0 Date: 14th of August, 2015
# Added Email notification list
####-------------------------------------------------------------------------
# REVISION HISTORY:
# #   $Log: Ops_FTP.pl,v $
# #   Revision 2.10  22th April, 2020  Ibrahim M.D
# #   Modified the script to be compatible Siyakhula environment (Linux)
# #   Convert the script from ftp and sftp file transfer.
#############################################################################
#BEGIN # necessary for this to execute properly from cron
#{
  #unshift @INC, qw(/sv/sv_app/gnu/perl/rel/lib/5.8.1 /sv/sv_app/gnu/perl/rel/lib/5.8.1/IA64.ARCHREV_0-LP64);
#}
use warnings;
my $MyEnv = `whoami`;
chomp $MyEnv;
use strict;
#use Net::FTP;
use Net::SFTP::Foreign;
use File::Path;
use File::Spec;
require "/sv/${MyEnv}/data/PE/lib/Ops_Functions.pl";

##
# Variable Declarations
##

#my $LogDir = '/sv/${MyEnv}/work/dantso_i/Ops_FTP'; # Launch info for test
my $LogDir = "/sv/${MyEnv}/data/PE/logs"; # Launch info for prod
my $myName = 'Ops_FTP';
#my $IniDir = "/sv/${MyEnv}/work/dantso_i/Ops_FTP"; # testing
my $IniDir = "/sv/${MyEnv}/data/PE/ini";  # prod
my $IniFile = "${myName}.ini";
my $IniLine; # contains lines from ini file
my @IniArray; #will contain parm and value for hash population
my %IniHash; # contains a hash of the initialization vars
my %opt; # command options hash
my $ftp; # FTP handle
my $sftp; # SFTP handle
my $key; # used to confirm the hash variables
my @date;
my $time; #YYMMDDHHMMSS
my $i; #generic var
my $logfile; # This is for the launch info
my $answer;
my $ArchiveFlag;
my $TempDir; # temp archive dir
my $ExitValue; # for system command return code checking
my $FileCount; # count the number of files ftp'd
my @FileList;
my $MsgHdr; # header for print statements
my $FndCust = 0;
my $RemSize;
my $LocSize;
my $eITCv = 'ITC';
my $eMList = 'EMAILLIST';
my @elines;
my @eList;
my @eListGrep;
my @eUncomment;
CHECK_PARMS() if $ARGV[0];

USAGEMSG() unless ($opt{c});
$MsgHdr = "${myName} -- ${opt{c}}:";

$time = &get_time();


$logfile = "${LogDir}/${myName}" . substr($time,0,8) . ".log";
open (LOG,">>$logfile") or
  die "** Ops_FTP.pl ERROR -- cannot open logfile $logfile\n";
Lprint("\n${MsgHdr} started at $time");

open (INI,"<${IniDir}/${IniFile}") || Ldie("${MsgHdr} ** Ops_FTP fatal error cannot" .
     " open INI file: ${IniDir}/${IniFile}");

while (<INI>)
{
 chomp;
 $IniLine = $_;
 CASE:
 {
  ($IniLine =~ /^#/) && last CASE;

  ($IniLine =~/^$opt{c}/) && do
  {
    $FndCust = 1;
    @IniArray = split(";",$IniLine);
    shift (@IniArray);
    $IniHash{$IniArray[0]} = $IniArray[1];
    last CASE;
  };
  last CASE;
 }
}
Ldie("${MsgHdr} Customer ${opt{c}} not configured in ini.  Exiting...") unless $FndCust;
#foreach $key (sort keys %IniHash)
#{
  #print "The value of $key is: $IniHash{$key}\n" if $IniHash{$key};
#}

##
# Before doing a bunch of work, confirm there are files to send
##

chdir(${IniHash{SOURCE}}) || Ldie("${MsgHdr} ${IniHash{SOURCE}} is not a valid source directory");
Lprint("${MsgHdr} Sourcing files from: ${IniHash{SOURCE}}");
@FileList = glob "*${IniHash{PATTERN}}*";
Ldie("${MsgHdr} No files to sftp in ${IniHash{SOURCE}}.  Exiting...") if scalar @FileList == 0;


##
# Check if we are archiving. If not: confirm.  If so, confirm dir
##

if ($IniHash{ARCHIVE})
{
  if (-d $IniHash{ARCHIVE}&& -W $IniHash{ARCHIVE})
  {
    $ArchiveFlag = 1;
##
# Here is how archive will work. create a temp folder in the archive directory
# based on time so will be unique.  Move the files there once sftp'd.  Once all
# the sftp'ing is done, tar and zip those files into the archive directory, and
# then remove the temporary directory along with the contents.
#
# We will create the temp dir now in the archive directory
##

    $TempDir = "${IniHash{ARCHIVE}}/temp_${time}";
    system("mkdir $TempDir");
    $ExitValue = $? >>8; # shift left 8 to find rc
    $ExitValue == 0 || Ldie("${MsgHdr} Error creating temp archive directory.  RC=$ExitValue");
  }
  else
  {
    Ldie("${MsgHdr} Problem accessing Archive dir $IniHash{ARCHIVE}. Can I write to it?");
  }
}
else
{
  Lprint("${MsgHdr} No Archive Directory Specified. Files will be left in place after FTP.");
  unless ($opt{q})
  {
    $answer = interactive("Is this okay");
print "Answer is: $answer\n";
    Ldie("${MsgHdr} User aborted due to no archiving") if $answer ne "Y";
  }
  $ArchiveFlag = 0;
  Lprint("$MsgHdr These files will NOT be archived");
}


##
# Now, prepare to sftp the files
##

Lprint ("${MsgHdr} Server: $IniHash{IP} User: $IniHash{ID}");
 $sftp = Net::SFTP::Foreign->new( $IniHash{IP},
                                    user => $IniHash{ID},
                                    stderr_discard => 1  );
   #Ldie("${MsgHdr} Unable to establish SFTP connection to $IniHash{IP}. Has ID changed? or Password expired?");
#$ftp->login($IniHash{ID}, $IniHash{PW}) or
   #Ldie("${MsgHdr} Error logging in. Has ID or password changed?");
#   Ldie("${MsgHdr} Error logging in. Has ID changed? or Password expired?");
#$sftp->binary();
  ( $sftp ) ||
      Ldie("${MsgHdr} Unable to establish SFTP connection to $IniHash{IP}. Please confirm IP and the password keys.");

if ($IniHash{TARGET})
{
  #$sftp->cwd($IniHash{TARGET}) ||
  $sftp->setcwd($IniHash{TARGET}) ||
    Ldie("${MsgHdr} Error changing to target dir: $IniHash{TARGET}");
  Lprint("${MsgHdr} copying to remote directory: $IniHash{TARGET}");
}
##
# Now we are ready to sftp.  Perl's FTP does not support mput so we have to
# do it one file at a time.  Bummer, man.
##

$FileCount=0;
foreach (@FileList)
{
  unless (-d "${_}")
  {
    $sftp->put("${_}") ||
     Ldie("${MsgHdr} Error uploading ${_}. Disk space or permissions problems?");
     Lprint("${MsgHdr} transfered $_");
       if (${opt{c}} eq $eITCv) {
      open eINPUT, "<${IniDir}/${IniFile}";
              @elines = <eINPUT>;
      close eINPUT;
      @eUncomment = grep {!/^#/} @elines;
         @eListGrep = grep (/$eMList/,@eUncomment);
             unless (@eListGrep) {
                    Ldie("${MsgHdr} Unable to filter email entry from INI file: ${IniDir}/${IniFile}. Please investigate.");
               }
             @eList = split(";","@eListGrep");
     system("echo \"Transferred ${_} File\"|mailx -s \"File: ${_} Transferred\" ${eList[-1]}");
     } else {
      Lprint("${MsgHdr} No email notification for Customer: ${opt{c}}");
     }
     $FileCount++;
     if ($opt{v})
     {
       #$RemSize = $ftp->size($_);
       my $Rsize = $sftp->stat($_);
       $RemSize = $Rsize->size;
       $LocSize = -s ${_};
       Lprint("${MsgHdr}: Local File Size: ${LocSize}");
       Lprint("${MsgHdr}: Remote File Size: ${RemSize}\n");
     }
##
# Archiving
##
    if ($ArchiveFlag)
    {
      system("mv ${_} $TempDir");
      $ExitValue = $? >>8; # shift left 8 to find rc
      Ldie("${MsgHdr} Error moving ${_} to $TempDir") unless $ExitValue == 0;
    }
  }
}
Lprint("${MsgHdr} $FileCount files transferred");
#$sftp->quit() or
$sftp->disconnect or
   Lprint("${MsgHdr} Error disconnecting.???");

CleanUp() unless $FileCount > 0;

##
# Now zip the archived files in the temp dir to the real archive dir, and delete
# the files and temp dir
##

if ($ArchiveFlag)
{
  Lprint("${MsgHdr} Archiving files to: $IniHash{ARCHIVE}");
  chdir("$TempDir") || Ldie("${MsgHdr} Failed changing to dir $TempDir to tar files");
system ("tar -cvf - *${IniHash{PATTERN}}* | gzip > $IniHash{ARCHIVE}/" .
        "${opt{c}}${time}.tar.gz");
  #system ("/usr/local/bin/tar -cvf - * | /usr/local/bin/gzip > $IniHash{ARCHIVE}/" .
  $ExitValue = $? >>8; # shift left 8 to find rc
   Ldie("${MsgHdr} Error zipping files from $TempDir to $IniHash{ARCHIVE}") unless $ExitValue == 0;
}
##
# Clean up and exit
##

CleanUp(); #This will also exit the script
exit; # Just in case

##
# Subroutines
##

##               ##
sub CleanUp      ##
##               ##
{
# clean up the tempdirs and temp files
chdir("$IniHash{ARCHIVE}") || Lprint("${MsgHdr} Failed changing to dir $IniHash{ARCHIVE} to begin cleanup.\n");
system("/bin/rm -rf $TempDir");
$ExitValue = $? >>8; # shift left 8 to find rc
Lprint("${MsgHdr} Warning: Unsuccessful deletion of temp space: $TempDir") unless $ExitValue == 0;

$time = &get_time();
Lprint("${MsgHdr} completed successfully at $time.");
exit 0;
}

##               ##
sub CHECK_PARMS  ##
##               ##
{
use Getopt::Std;
# the : is needed after the switch if an argument is expected.
  getopts("c:qvh", \%opt) || &USAGEMSG;

  &USAGEMSG() if $opt{h};

##
# This is all that is necessary.  Parameter values now in hash
##
}

##            ##
sub USAGEMSG  ##
##            ##

{
  print STDERR << "EOF";

This script ftp's files to customers as defined in the Ops_FTP.ini file

Usage: $0 -c CUSTOMER [-q][-v][-h]  WHERE

      -c CUSTOMER  : CUSTOMER is the customer code as per the ini file
      -q           : Quiet: does not ask for confirmation if no Archive
      -v           : Verbose: prints local and remote filesize for each file sent
      -h           : this (help) message

    example: $0 -c ITC
EOF
exit;
}
svc_cyk_SingleVR_App.sklsvprd.nlasvwrva10> (/sv/sklsvprd/data/PE/scripts)
$
