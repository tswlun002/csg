#!/usr/bin/perl
use warnings;
use strict;
use File::Path;
use File::Spec;
my $MyEnv = `whoami`;
chomp $MyEnv;
#require "/sv/${MyEnv}/data/PE/lib/Ops_Functions.pl";
require "/home/${MyEnv}/Documents/job/lib/Ops_Functions.pl";



##
# Variable Declarations
##
my $myName = 'Ops_FTP';
my $ArchiveFlag;
my $TempDir; # temp archive dir
my %IniHash; # contains a hash of the initialization vars
my %opt; # command options hash
my $MsgHdr; # header for print statements
my $time; #YYMMDDHHMMSS
my $logfile; # This is for the launch info
my $LogDir = "/home/${MyEnv}/Documents/job/logs/" ;#/sv/${MyEnv}/data/PE/logs"; # Launch info for prod
my $IniDir = "/home/${MyEnv}/Documents/job/init"; #"/sv/${MyEnv}/data/PE/ini";  # prod
my $IniFile = "${myName}.ini";
my $IniLine; # contains lines from ini file
my @IniArray; #will contain parm and value for hash population
my $FndCust = 0;
my $ExitValue; # for system command return code checking
my $answer;
my @FileList;


#CHECK_PARMS() if $ARGV[0];

#USAGEMSG() unless ($opt{c});
$MsgHdr = "${myName} -- ${opt{c}}:";

$time = &get_time();


$logfile = "${LogDir}/${myName}" . substr($time,0,8) . ".log";
open(LOG,">>$logfile") or
 die "** Ops_FTP.pl ERROR -- cannot open logfile $logfile\n";
Lprint("\n${MsgHdr} started at $time");
close LOG;

open (INI,"<${IniDir}/${IniFile}") || Ldie("${MsgHdr} ** Ops_FTP fatal error cannot" .
     " open INI file: ${IniDir}/${IniFile}");

while (<INI>)
{
 chomp;
 $IniLine = $_;
 CASE:
 {
  ($IniLine =~ /^#/) && last CASE;

  ($IniLine =~/^$opt{c}/) && do
  {
    $FndCust = 1;
    @IniArray = split(";",$IniLine);
    shift (@IniArray);
    $IniHash{$IniArray[0]} = $IniArray[1];
    last CASE;
  };
  last CASE;
 }
}
Ldie("${MsgHdr} Customer ${opt{c}} not configured in ini.  Exiting...") unless $FndCust;


##
# Before doing a bunch of work, confirm there are files to send
##

chdir(${IniHash{SOURCE}}) || Ldie("${MsgHdr} ${IniHash{SOURCE}} is not a valid source directory");
Lprint("${MsgHdr} Sourcing files from: ${IniHash{SOURCE}}");
@FileList = glob "*${IniHash{PATTERN}}*";
Ldie("${MsgHdr} No files to sftp in ${IniHash{SOURCE}}.  Exiting...") if scalar @FileList == 0;


##
# Check if we are archiving. If not: confirm.  If so, confirm dir
##

if ($IniHash{ARCHIVE})
{
  if (-d $IniHash{ARCHIVE}&& -W $IniHash{ARCHIVE})
  {
    $ArchiveFlag = 1;

    ##
    # Here is how archive will work. create a temp folder in the archive directory
    # based on time so will be unique.  Move the files there once sftp'd.  Once all
    # the sftp'ing is done, tar and zip those files into the archive directory, and
    # then remove the temporary directory along with the contents.
    #
    # We will create the temp dir now in the archive directory
    ##
     $TempDir = "${IniHash{ARCHIVE}}/temp_${time}";
    system("mkdir $TempDir");
    $ExitValue = $? >>8; # shift left 8 to find rc
    $ExitValue == 0 || Ldie("${MsgHdr} Error creating temp archive directory.  RC=$ExitValue");
  }
  else
  {
    Ldie("${MsgHdr} Problem accessing Archive dir $IniHash{ARCHIVE}. Can I write to it?");
  }
}

else
{
  Lprint("${MsgHdr} No Archive Directory Specified. Files will be left in place after FTP.");
  unless ($opt{q})
  {
    $answer = interactive("Is this okay");
    print "Answer is: $answer\n";
    Ldie("${MsgHdr} User aborted due to no archiving") if $answer ne "Y";
  }
  $ArchiveFlag = 0;
  Lprint("$MsgHdr These files will NOT be archived");
}
foreach (@FileList)
{
  unless (-d "${_}")
  {
    ##
    # Archiving
    ##
    if ($ArchiveFlag)
    {
        system("mv ${_} $TempDir");
        $ExitValue = $? >>8; # shift left 8 to find rc
        Ldie("${MsgHdr} Error moving ${_} to $TempDir") unless $ExitValue == 0;
    }
  }
}

##
# Now zip the archived files in the temp dir to the real archive dir, and delete
# the files and temp dir
##
if ($ArchiveFlag)
{
  Lprint("${MsgHdr} Archiving files to: $IniHash{ARCHIVE}");
  chdir("$TempDir") || Ldie("${MsgHdr} Failed changing to dir $TempDir to tar files");
system ("tar -cvf - *${IniHash{PATTERN}}* | gzip > $IniHash{ARCHIVE}/" .
        "${opt{c}}${time}.tar.gz");
  #system ("/usr/local/bin/tar -cvf - * | /usr/local/bin/gzip > $IniHash{ARCHIVE}/" .
  $ExitValue = $? >>8; # shift left 8 to find rc
   Ldie("${MsgHdr} Error zipping files from $TempDir to $IniHash{ARCHIVE}") unless $ExitValue == 0;
}
##
# Clean up and exit
##

CleanUp(); #This will also exit the script
exit; # Just in case

##
# Subroutines
##

##               ##
sub CleanUp      ##
##               ##
{
# clean up the tempdirs and temp files
chdir("$IniHash{ARCHIVE}") || Lprint("${MsgHdr} Failed changing to dir $IniHash{ARCHIVE} to begin cleanup.\n");
system("/bin/rm -rf $TempDir");
$ExitValue = $? >>8; # shift left 8 to find rc
Lprint("${MsgHdr} Warning: Unsuccessful deletion of temp space: $TempDir") unless $ExitValue == 0;

$time = &get_time();
Lprint("${MsgHdr} completed successfully at $time.");
exit 0;
}

=CHECK_PARMS
##               ##
sub CHECK_PARMS  ##
##               ##
{
use Getopt::Std;
# the : is needed after the switch if an argument is expected.
  getopts("c:qvh", \%opt) || &USAGEMSG;

  &USAGEMSG() if $opt{h};

=cut

=USAGEMSG

##
# This is all that is necessary.  Parameter values now in hash
##
}


##            ##
sub USAGEMSG  ##
##            ##

{
  print STDERR << "EOF";

This script ftp's files to customers as defined in the Ops_FTP.ini file

Usage: $0 -c CUSTOMER [-q][-v][-h]  WHERE

      -c CUSTOMER  : CUSTOMER is the customer code as per the ini file
      -q           : Quiet: does not ask for confirmation if no Archive
      -v           : Verbose: prints local and remote filesize for each file sent
      -h           : this (help) message

    example: $0 -c ITC
EOF
exit;
}
=cut