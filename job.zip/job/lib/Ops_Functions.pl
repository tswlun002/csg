
=COMMMAND
svc_cyk_SingleVR_App.sklsvprd.nlasvwrva10> (/sv/sklsvprd/data/PE/lib)
$ ls -lrt Ops_Functions.pl
-rwxr-xr-x 1 sklsvprd sv 1279 Mar 31 2020 Ops_Functions.pl
svc_cyk_SingleVR_App.sklsvprd.nlasvwrva10> (/sv/sklsvprd/data/PE/lib)
$ cat Ops_Functions.pl
=cut
#!/usr/bin/perl
# This file contains functions and subroutines for inclusion in various
# operational perl scripts.


#use strict;


##
sub Lprint
{
##



#
# Usage: Lprint("put whatever you want to say here")



# prints to the LOG device, as well as the screen



 my $Message = $_[0];



 print LOG "$Message\n";
 print "$Message\n";
 return (1);
}




##
sub Ldie
{
##



#
# Usage: Ldie("put whatever you want to say here")



# prints to the LOG device, as well as the screen, then exits



 my $Message = $_[0];
 print LOG "$Message\n";
 print "$Message\n";
 exit 1;
}






## ##
sub get_time ##
## ##



# This subroutine returns yymmddHHMMSS
# usage: $var = &get_time();



{



 my $time;
 my @date;



 @date = localtime();
 $time = sprintf("%04d%02d%02d%02d%02d%02d",$date[5] + 1900,$date[4]+1,$date[3],
 $date[2],$date[1],$date[0]);
 return $time;
}



## ##
sub interactive #
## ##
#
# This takes a "message" as input and returns the Y or N answer
#



{
 my $ans;
 my $ans_okay = 1;



 while ($ans_okay == 1)
 {
 print " @_ (y or n)?";
 $ans = uc <STDIN>;
 chomp $ans;
 ($ans =~ /["Y","N"]/) && (1 == length($ans)) && ($ans_okay = 2);
 }
 return $ans;
}
1;